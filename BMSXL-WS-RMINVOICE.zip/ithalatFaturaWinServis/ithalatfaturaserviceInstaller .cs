﻿using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace ithalatFaturaWinServis
{
    [RunInstaller(true)]
    public class ithalatFaturaWinServisInstaller : Installer
    {
        public ithalatFaturaWinServisInstaller()
        {
            var spi = new ServiceProcessInstaller();
            var si = new ServiceInstaller();

            spi.Account = ServiceAccount.LocalSystem;
            spi.Username = null;
            spi.Password = null;

            si.DisplayName = Program.ServiceName;
            si.ServiceName = Program.ServiceName;
            si.StartType = ServiceStartMode.Automatic;

            Installers.Add(spi);
            Installers.Add(si);
        }
    }
}