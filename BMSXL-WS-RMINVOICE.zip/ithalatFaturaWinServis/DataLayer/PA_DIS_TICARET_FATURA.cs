﻿using ithalatFaturaWinServis.DataLayer.Helpers;
using ithalatFaturaWinServis.DataLayer.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Devart.Data.Oracle;
using ithalatFaturaWinServis.Helpers;

namespace ithalatFaturaWinServis.DataLayer
{
    public class PA_DIS_TICARET_FATURA
    {
        public static Sonuc ithalatFaturaTrnTempKaydet(DataTable rminvoice)
        {

            Sonuc sonuc = new Sonuc();
            sonuc.ds = new DataSet();


            string connStr = Baglantiislemleri.UygulamaBaglantiBilgisiVer();
            OracleConnection myConnection = new OracleConnection(connStr);

            OracleDataAdapter myDA = new OracleDataAdapter("HBMS.PA_DIS_TICARET_FATURA_WS.PR_ITH_FATURA_TRN_TEMP_KAYDET", myConnection);
            myDA.SelectCommand.CommandType = CommandType.StoredProcedure;


            try
            {

                StringBuilder pcl_parametre = new StringBuilder();

                pcl_parametre.Append("<LISTE_XML>");

                foreach (DataRow dr in rminvoice.Rows)
                {

                    pcl_parametre.Append("<KAYIT>");

                    pcl_parametre.Append("<INVOICE_CODE>" + Temelislemler.CDATAver(dr["INVOICE_CODE"].ToString()) + "</INVOICE_CODE>");
                    pcl_parametre.Append("<HB_MATERIAL_CODE>" + Temelislemler.CDATAver(dr["HB_MATERIAL_CODE"].ToString()) + "</HB_MATERIAL_CODE>");
                    pcl_parametre.Append("<RENK_KOD>" + Temelislemler.CDATAver(dr["RENK_KOD"].ToString()) + "</RENK_KOD>");
                    pcl_parametre.Append("<BEDEN_KOD>" + Temelislemler.CDATAver(dr["BEDEN_KOD"].ToString()) + "</BEDEN_KOD>");
                    pcl_parametre.Append("<BIRIM>" + Temelislemler.CDATAver(dr["BIRIM"].ToString()) + "</BIRIM>");
                    pcl_parametre.Append("<GRQTY>" + Temelislemler.CDATAver(dr["GRQTY"].ToString()) + "</GRQTY>");
                    pcl_parametre.Append("<NETQTY>" + Temelislemler.CDATAver(dr["NETQTY"].ToString()) + "</NETQTY>");
                    pcl_parametre.Append("<PRICE>" + Temelislemler.CDATAver(dr["PRICE"].ToString()) + "</PRICE>");
                    pcl_parametre.Append("<TOTAL_VALUE>" + Temelislemler.CDATAver(dr["TOTAL_VALUE"].ToString()) + "</TOTAL_VALUE>");
                    pcl_parametre.Append("<DOVIZ_CINS>" + Temelislemler.CDATAver(dr["DOVIZ_CINS"].ToString()) + "</DOVIZ_CINS>");
                    pcl_parametre.Append("<AGIRLIK_BIRIM>" + Temelislemler.CDATAver(dr["AGIRLIK_BIRIM"].ToString()) + "</AGIRLIK_BIRIM>");
                    pcl_parametre.Append("<GRQTY_KG>" + Temelislemler.CDATAver(dr["GRQTY_KG"].ToString()) + "</GRQTY_KG>");
                    pcl_parametre.Append("<NETQTY_KG>" + Temelislemler.CDATAver(dr["NETQTY_KG"].ToString()) + "</NETQTY_KG>");
                    pcl_parametre.Append("<ULKE_KOD>" + Temelislemler.CDATAver(dr["ULKE_KOD"].ToString()) + "</ULKE_KOD>");
                    pcl_parametre.Append("<GTIP_KOD>" + Temelislemler.CDATAver(dr["GTIP_KOD"].ToString()) + "</GTIP_KOD>");
                    pcl_parametre.Append("<BEDEN_ACIKLAMA>" + Temelislemler.CDATAver(dr["BEDEN_ACIKLAMA"].ToString()) + "</BEDEN_ACIKLAMA>");
                    pcl_parametre.Append("<KATSAYI>" + Temelislemler.CDATAver(dr["KATSAYI"].ToString()) + "</KATSAYI>");
                    pcl_parametre.Append("</KAYIT>");

                }


                pcl_parametre.Append("</LISTE_XML>");

                myDA.SelectCommand.Parameters.Add(Temelislemler.parametreEkle(pcl_parametre.ToString(), "IN_PRM", OracleDbType.Clob));


                myConnection.Open();
                myDA.Fill(sonuc.ds);
                myConnection.Close();
                myDA.Dispose();

                sonuc.ds.Tables[0].TableName = "out_sonuc";

                sonuc.SONUC_KOD = Convert.ToDecimal(sonuc.ds.Tables["out_sonuc"].Rows[0]["SONUC_KOD"].ToString());
                sonuc.SONUC_MESAJ = sonuc.ds.Tables["out_sonuc"].Rows[0]["SONUC_MESAJ"].ToString();

            }
            catch (Exception ex)
            {
                sonuc.ds = null;
                sonuc.SONUC_KOD = -1999;
                sonuc.SONUC_MESAJ = "Method:ithalatFaturaTrnTempKaydet Hata: uygulama seviyesinde hata - " + ex.Message;
                YardimciFonksiyonlar.SendRMinvoiceErrorMail(sonuc);
            }
            finally
            {

                myConnection.Close();
                myDA.Dispose();

            }


            return sonuc;


        }


        public static Sonuc ithalatFaturaTrnSil(string INVOICE_CODE)
        {

            Sonuc sonuc = new Sonuc();
            sonuc.ds = new DataSet();


            string connStr = Baglantiislemleri.UygulamaBaglantiBilgisiVer();
            OracleConnection myConnection = new OracleConnection(connStr);

            OracleDataAdapter myDA = new OracleDataAdapter("HBMS.PA_DIS_TICARET_FATURA_WS.PR_ITH_FATURA_TRN_SIL", myConnection);
            myDA.SelectCommand.CommandType = CommandType.StoredProcedure;


            try
            {

                myDA.SelectCommand.Parameters.Add(Temelislemler.parametreEkle(INVOICE_CODE.ToString(), "IN_INVOICE_CODE", OracleDbType.VarChar));

                myConnection.Open();
                myDA.Fill(sonuc.ds);
                myConnection.Close();
                myDA.Dispose();

                sonuc.ds.Tables[0].TableName = "out_sonuc";

                sonuc.SONUC_KOD = Convert.ToDecimal(sonuc.ds.Tables["out_sonuc"].Rows[0]["SONUC_KOD"].ToString());
                sonuc.SONUC_MESAJ = sonuc.ds.Tables["out_sonuc"].Rows[0]["SONUC_MESAJ"].ToString();

            }
            catch (Exception ex)
            {
                sonuc.ds = null;
                sonuc.SONUC_KOD = -1999;
                sonuc.SONUC_MESAJ = "Method:ithalatFaturaTrnSil Hata: uygulama seviyesinde hata - " + ex.Message;
                YardimciFonksiyonlar.SendRMinvoiceErrorMail(sonuc);
            }
            finally
            {

                myConnection.Close();
                myDA.Dispose();

            }


            return sonuc;


        }

    }
}
