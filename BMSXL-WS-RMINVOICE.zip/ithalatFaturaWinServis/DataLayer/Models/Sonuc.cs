﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ithalatFaturaWinServis.DataLayer.Models
{
    public class Sonuc
    {
        public Decimal PK_NO; //primary key
        public Decimal SONUC_KOD;
        public string SONUC_MESAJ;

        public DataSet ds;
        public Object obj;

        public Sonuc()
        {
            SONUC_KOD = -101;
            SONUC_MESAJ = "";

            ds = null;
            obj = null;

        }

    }
}
