﻿using Devart.Data.Oracle;
using System.Data;

namespace ithalatFaturaWinServis.DataLayer.Helpers
{
    public class Temelislemler
    {
        public static OracleParameter parametreEkle(object objDeger, string objAd, OracleDbType oracleTip)
        {

            if ((objDeger == null) && (oracleTip == OracleDbType.Number))
            {
                objDeger = 0;
            }

            OracleParameter par = new OracleParameter(objAd, oracleTip);
            par.ParameterName = objAd;
            par.Value = objDeger;
            par.Direction = ParameterDirection.Input;

            return par;

        }
        public static string CDATAver(string veri)
        {
            return "<![CDATA[" + veri + "]]>";
        }

    }
}
