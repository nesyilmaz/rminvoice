﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace ithalatFaturaWinServis.DataLayer.Helpers
{
    public class Baglantiislemleri
    {

        public static string UygulamaBaglantiBilgisiVer()
        {
            return ConfigurationManager.ConnectionStrings["BMSDB"].ConnectionString;

        }

    }
}
