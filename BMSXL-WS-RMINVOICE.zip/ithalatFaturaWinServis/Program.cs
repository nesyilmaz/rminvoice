﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceProcess;
using myservice;

using System.Timers;
using System.IO;
using ithalatFaturaWinServis.Helpers;
using System.Data;
using ithalatFaturaWinServis.DataLayer;
using ithalatFaturaWinServis.DataLayer.Models;

namespace ithalatFaturaWinServis
{
    class Program
    {
        public const string ServiceName = "ithalatFaturaService";

        private static Timer timer = new Timer();

       
        static void Main(string[] args)
        {
            if (Environment.UserInteractive)
            {
                // running as console app
                Start(args);

                Console.WriteLine("Press any key to stop...");
                Console.ReadKey(true);

                Stop();
            }
            else
            {
                // running as service
                using (var service = new Service())
                {
                    ServiceBase.Run(service);
                }
            }
        }

        public static void Start(string[] args)
        {
          
            string INTERVAL_DK = YardimciFonksiyonlar.intervalDKVer();
            int INTERVAL = Convert.ToInt32(INTERVAL_DK) * 60 * 1000; 

            Start_Transfer_RM_invoice();

            timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);
            timer.Interval = INTERVAL;
            timer.Enabled = true;

        }

        public static void Stop()
        {
            
        }

        public static void Start_Transfer_RM_invoice()
        {
            try
            {
                Object[] files = YardimciFonksiyonlar.getFilesToTransfer("*RM_INVOICE*.*");
                Dictionary<string, TransferFileInfo> fileList = (Dictionary<string, TransferFileInfo>)files[0];

                foreach (TransferFileInfo tfi in fileList.Values)
                {
                    try
                    {
                        DataTable dt_tempINVOICE = YardimciFonksiyonlar.readINVOICEFile(tfi.TransferDosya.FullName);

                        // once silme islemi yapılır.
                        Sonuc sonucSilme = PA_DIS_TICARET_FATURA.ithalatFaturaTrnSil(tfi.OrderNo);
                        if (sonucSilme.SONUC_KOD > 0)
                        {
                            // sonra kaydetme islemi yapılır.
                            Sonuc sonuc = PA_DIS_TICARET_FATURA.ithalatFaturaTrnTempKaydet(dt_tempINVOICE);
                            if (sonuc.SONUC_KOD > 0)
                            {
                                tfi.TransferDosya.MoveTo(YardimciFonksiyonlar.rminvoiceTransferMoveFolderVer() + "\\" + tfi.TransferDosya.Name);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Sonuc snc = new Sonuc();
                        snc.SONUC_KOD   = -200;
                        snc.SONUC_MESAJ = "INVOICE CODE:"+tfi.OrderNo+" Hata:"+ex.Message;
                        YardimciFonksiyonlar.SendRMinvoiceErrorMail(snc);
                    }
                   

                }
            }
            catch (Exception ex)
            {
                Sonuc sonuc         = new Sonuc();
                sonuc.SONUC_KOD     = -100;
                sonuc.SONUC_MESAJ   = ex.Message;
                YardimciFonksiyonlar.SendRMinvoiceErrorMail(sonuc);
            }
            

        }

        private static void OnElapsedTime(object source, ElapsedEventArgs e)
        {
            Console.WriteLine(DateTime.Now.ToString());
            Start_Transfer_RM_invoice();
        }


    }
}
