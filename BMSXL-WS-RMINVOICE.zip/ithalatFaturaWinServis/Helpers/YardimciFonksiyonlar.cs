﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;
using System.Data;
using ithalatFaturaWinServis.DataLayer.Models;
using System.Net.Mail;

namespace ithalatFaturaWinServis.Helpers
{
    public class YardimciFonksiyonlar
    {
        private const int INVOICE_FILE_INVOICECODE = 4;
        private const int INVOICE_FILE_HB_MATERIALCODE = 6;
        private const int INVOICE_FILE_RENKKOD = 8;
        private const int INVOICE_FILE_BEDENKOD = 10;
        private const int INVOICE_FILE_BEDEN_ACIKLAMA = 11;
        private const int INVOICE_FILE_BIRIM = 12;
        private const int INVOICE_FILE_GRQTY = 13;
        private const int INVOICE_FILE_NETQTY = 14;
        private const int INVOICE_FILE_PRICE = 15;
        private const int INVOICE_FILE_TOTALVALUE = 16;
        private const int INVOICE_FILE_DOVIZ_CINS = 17;
        private const int INVOICE_FILE_AGIRLIK_BIRIM = 18;
        private const int INVOICE_FILE_GRQTY_KG = 19;
        private const int INVOICE_FILE_NETQTY_KG = 20;
        private const int INVOICE_FILE_ULKEKOD = 21;
        private const int INVOICE_FILE_GTIPKOD = 22;
        private const int INVOICE_FILE_KATSAYI = 23;

        public static string intervalDKVer()
        {
            return ConfigurationManager.AppSettings["INTERVAL_DK"];
        }
        public static string rminvoiceTransferFolderVer()
        {
            return ConfigurationManager.AppSettings["RMINVOICETRANSFERFOLDER"];
        }
        public static string rminvoiceTransferMoveFolderVer()
        {
            return ConfigurationManager.AppSettings["RMINVOICETRANSFERMOVEFOLDER"];
        }

        public static string mailToVer()
        {
            return ConfigurationManager.AppSettings["MAIL_TO"];
        }

        public static string mailCCVer()
        {
            return ConfigurationManager.AppSettings["MAIL_CC"];
        }

        public static string mailFromVer()
        {
            return ConfigurationManager.AppSettings["MAIL_FROM"];
        }

        public static Object[] getFilesToTransfer(string p_searchPattern)
        {
            // Transfer dosyaları klasörü içinde yer alan dosyalardan işlem yapılacak olanlarının
            // tutulacağı liste.
            Dictionary<string, TransferFileInfo> fileList = new Dictionary<string, TransferFileInfo>();

            // Transfer dosyaları klasörü içinde yer alan dosyalardan işlem yapılmayacak olanlarının
            // tutulacağı liste.
            List<TransferFileInfo> fileListDuplicates = new List<TransferFileInfo>();

            // Dosya adının başında Order numarası yazıyor mu kontrolü için gerekli regex tanımı.
            Regex orderDesen = new Regex("[0-9]");


            TransferFileInfo tempFile = null;
            DirectoryInfo dir = new DirectoryInfo(rminvoiceTransferFolderVer());
            FileInfo[] files = dir.GetFiles(p_searchPattern);
            foreach (FileInfo f in files)
            {
                string orderNo = "";
                orderNo = f.Name.Substring(0, f.Name.IndexOf("_"));   //f.Name.Substring(0,10);
                if (f.Name.Contains("_RM_INVOICE"))
                {
                    orderNo = orderNo.ToString().Trim().TrimStart(new char[] { '0' });
                }

                if (orderDesen.IsMatch(orderNo) && f.Name.Contains("_RM_INVOICE"))
                {
                    // İşlem yapılacak dosyalar listesine eklenicek TransferFileInfo nesnesinin oluşturulması.
                    tempFile = new TransferFileInfo();
                    tempFile.OrderNo = orderNo;
                    tempFile.TransferDosya = f;
                    tempFile.DosyaYeniPath = rminvoiceTransferMoveFolderVer() + "\\" + f.Name;

                    if (f.Name.Contains("_RM_INVOICE")) tempFile.DosyaTipi = TransferFileInfo.FileTip.INVOICE;

                    // İlgili dosyanın OrderNo + DosyaTip bilgileri ile oluşturulan o transfer dosyasını tanımlayan PK.
                    string dosyaKey = tempFile.OrderNo + tempFile.DosyaTipi;

                    // İlgili dosya listede yoksa direk eklenir, listede var ise yeni eklenmek istenen ancak tarih değeri
                    // daha büyükse eklenir.
                    if (!fileList.ContainsKey(dosyaKey))
                    {
                        fileList.Add(dosyaKey, tempFile);
                    }
                    else
                    {
                        if (tempFile.TransferDosya.LastWriteTime > fileList[dosyaKey].TransferDosya.LastWriteTime)
                        {
                            fileListDuplicates.Add(fileList[dosyaKey]);
                            fileList.Remove(dosyaKey);
                            fileList.Add(dosyaKey, tempFile);
                        }
                        else
                        {
                            fileListDuplicates.Add(tempFile);
                        }
                    }
                } // end if
            } // end foreach 

            Object[] result = new Object[2];
            result[0] = fileList;
            result[1] = fileListDuplicates;
            return result;
        }

        public static DataTable readINVOICEFile(string invoiceFile)
        {
            DataTable invoiceDT = new DataTable();
            invoiceDT.TableName = "INVOICE";

            #region INVOICE_DataTable COLUMN yaratılması
            DataColumn c1 = new DataColumn("FATURA_TRN_NO", typeof(Int32));
            DataColumn c2 = new DataColumn("FABRIKA_KOD", typeof(string));
            DataColumn c3 = new DataColumn("DIVISION_KOD", typeof(decimal));
            DataColumn c4 = new DataColumn("INVOICE_CODE", typeof(string));
            DataColumn c5 = new DataColumn("HB_MATERIAL_CODE", typeof(string));
            DataColumn c6 = new DataColumn("RENK_KOD", typeof(string));
            DataColumn c7 = new DataColumn("BEDEN_KOD", typeof(string));
            DataColumn c8 = new DataColumn("BIRIM", typeof(string));
            DataColumn c9 = new DataColumn("GRQTY", typeof(decimal));
            DataColumn c10 = new DataColumn("NETQTY", typeof(decimal));
            DataColumn c11 = new DataColumn("PRICE", typeof(decimal));
            DataColumn c12 = new DataColumn("TOTAL_VALUE", typeof(decimal));
            DataColumn c13 = new DataColumn("DOVIZ_CINS", typeof(string));
            DataColumn c14 = new DataColumn("AGIRLIK_BIRIM", typeof(string));
            DataColumn c15 = new DataColumn("GRQTY_KG", typeof(decimal));
            DataColumn c16 = new DataColumn("NETQTY_KG", typeof(decimal));
            DataColumn c17 = new DataColumn("ULKE_KOD", typeof(string));
            DataColumn c18 = new DataColumn("GTIP_KOD", typeof(string));
            DataColumn c19 = new DataColumn("KAYIT_DURUM", typeof(string));
            DataColumn c20 = new DataColumn("SW_CHECKED", typeof(decimal));
            DataColumn c21 = new DataColumn("CHECK_INFO", typeof(string));
            DataColumn c22 = new DataColumn("CHECK_ERROR_CODE", typeof(string));
            DataColumn c23 = new DataColumn("G_SIRA_NO", typeof(decimal));
            DataColumn c24 = new DataColumn("MALZEME_KOD", typeof(string));
            DataColumn c25 = new DataColumn("BEDEN_ACIKLAMA", typeof(string));
            DataColumn c26 = new DataColumn("SEVKIYAT_NO", typeof(string));
            DataColumn c27 = new DataColumn("ULKE_KISA_KOD", typeof(string));
            DataColumn c28 = new DataColumn("KATSAYI", typeof(decimal));

            invoiceDT.Columns.AddRange(new DataColumn[] { c1,  c2,  c3,  c4,  c5,  c6,  c7,  c8,  c9,
                                                    c10, c11, c12, c13, c14, c15, c16, c17, c18, c19,
                                                    c20, c21, c22, c23, c24, c25, c26, c27, c28 });
            #endregion

            using (StreamReader sr = new StreamReader(invoiceFile, Encoding.GetEncoding("windows-1254")))
            {
                string input = null;
                while ((input = sr.ReadLine()) != null)
                {
                    DataRow tempINVOICE = invoiceDT.NewRow();

                    string[] fieldINVOICE = input.Split(new char[] { ';' });

                    tempINVOICE["INVOICE_CODE"] = fieldINVOICE[INVOICE_FILE_INVOICECODE].ToString().Trim().TrimStart(new char[] { '0' });
                    tempINVOICE["HB_MATERIAL_CODE"] = fieldINVOICE[INVOICE_FILE_HB_MATERIALCODE].ToString();
                    if (tempINVOICE[INVOICE_FILE_RENKKOD].ToString().Trim().Length < 3)
                    {
                        tempINVOICE["RENK_KOD"] = fieldINVOICE[INVOICE_FILE_RENKKOD].ToString().PadLeft(3, '0');
                    }
                    else
                    {
                        tempINVOICE["RENK_KOD"] = fieldINVOICE[INVOICE_FILE_RENKKOD].ToString();
                    }
                    tempINVOICE["BEDEN_KOD"] = fieldINVOICE[INVOICE_FILE_BEDENKOD].ToString().Replace(".", ",");
                    tempINVOICE["BIRIM"] = fieldINVOICE[INVOICE_FILE_BIRIM].ToString();
                    tempINVOICE["GRQTY"] = decimal.Parse(fieldINVOICE[INVOICE_FILE_GRQTY].ToString());
                    tempINVOICE["NETQTY"] = decimal.Parse(fieldINVOICE[INVOICE_FILE_NETQTY].ToString());
                    tempINVOICE["PRICE"] = decimal.Parse(fieldINVOICE[INVOICE_FILE_PRICE].ToString());
                    tempINVOICE["TOTAL_VALUE"] = decimal.Parse(fieldINVOICE[INVOICE_FILE_TOTALVALUE].ToString());
                    tempINVOICE["DOVIZ_CINS"] = fieldINVOICE[INVOICE_FILE_DOVIZ_CINS].ToString();
                    tempINVOICE["AGIRLIK_BIRIM"] = fieldINVOICE[INVOICE_FILE_AGIRLIK_BIRIM].ToString();
                    tempINVOICE["GRQTY_KG"] = decimal.Parse(fieldINVOICE[INVOICE_FILE_GRQTY_KG].ToString());
                    tempINVOICE["NETQTY_KG"] = decimal.Parse(fieldINVOICE[INVOICE_FILE_NETQTY_KG].ToString());
                    tempINVOICE["ULKE_KOD"] = fieldINVOICE[INVOICE_FILE_ULKEKOD].ToString();
                    tempINVOICE["GTIP_KOD"] = fieldINVOICE[INVOICE_FILE_GTIPKOD].ToString();
                    tempINVOICE["BEDEN_ACIKLAMA"] = fieldINVOICE[INVOICE_FILE_BEDEN_ACIKLAMA].ToString().Replace(".", ",");
                    //tempINVOICE["KATSAYI"]                = decimal.Parse(fieldINVOICE[INVOICE_FILE_KATSAYI].ToString());

                    if ((fieldINVOICE[INVOICE_FILE_KATSAYI] == null) ||
                        (fieldINVOICE[INVOICE_FILE_KATSAYI].ToString() == String.Empty) ||
                        (decimal.Parse(fieldINVOICE[INVOICE_FILE_KATSAYI].ToString()) == 0))
                        tempINVOICE["KATSAYI"] = 1;
                    else
                        tempINVOICE["KATSAYI"] = decimal.Parse(fieldINVOICE[INVOICE_FILE_KATSAYI].ToString());

                    if (tempINVOICE["NETQTY"] != null)
                    {
                        if (decimal.Parse(tempINVOICE["NETQTY"].ToString()) != decimal.Parse("0"))
                        {
                            invoiceDT.Rows.Add(tempINVOICE);
                        }
                    }


                }
            }
            return invoiceDT;
        }

        public static void SendRMinvoiceErrorMail( Sonuc sonuc )
        {


            string from = mailFromVer();
            string toArr = YardimciFonksiyonlar.mailToVer();
            string ccArr = YardimciFonksiyonlar.mailCCVer();
            string subject = "RM INVOICE Hata Bilgilendirme Hk.";
            string body = "<table border='1' cellpadding='1' cellspacing='1'>" +
                            " <tbody>" +
                                 "<tr>" +
                                     "<td> SONUC KOD </td>" +
                                     "<td>" + sonuc.SONUC_KOD + "</td>" +
                                 "</tr>" +
                                 "<tr>" +
                                     "<td> SONUC MESSAGE </td>" +
                                     "<td>" + sonuc.SONUC_MESAJ + "</td>" +
                                 "</tr>" +
                             "</tbody>" +
                       " </table> ";

            MailMessage msg = new MailMessage();

            msg.From = new MailAddress(from);
            //---------------------------------------------
            string[] to = toArr.Split(',');
            for (int i = 0; i < to.Length; i++)
            {
                if (!string.IsNullOrEmpty(to[i]))
                {
                    msg.To.Add(to[i]);
                }
            }
            //---------------------------------------------
            string[] cc = ccArr.Split(',');
            for (int j = 0; j < cc.Length; j++)
            {
                if (!string.IsNullOrEmpty(cc[j]))
                {
                    msg.CC.Add(cc[j]);
                }
            }
            //---------------------------------------------

            msg.Body = body;
            msg.IsBodyHtml = true;
            msg.BodyEncoding = System.Text.Encoding.GetEncoding("utf-8");

            msg.Priority = MailPriority.High;
            msg.Subject = subject;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.hugoboss.com";
            smtp.EnableSsl = false;
            smtp.Credentials = new System.Net.NetworkCredential("bilgi_islem", "sezenaksu");
            smtp.Send(msg);

        }




    }
}
