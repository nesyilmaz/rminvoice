﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ithalatFaturaWinServis
{
    public class TransferFileInfo
    {

            public enum FileTip
            {

                INVOICE = 5
            }

            private string orderNo;
            private FileTip dosyaTipi;
            private FileInfo transferDosya;
            private string dosyaYeniPath;

            public string OrderNo
            {
                get { return orderNo; }
                set { orderNo = value; }
            }

            public FileTip DosyaTipi
            {
                get { return dosyaTipi; }
                set { dosyaTipi = value; }
            }

            public FileInfo TransferDosya
            {
                get { return transferDosya; }
                set { transferDosya = value; }
            }

            public string DosyaYeniPath
            {
                get { return dosyaYeniPath; }
                set { dosyaYeniPath = value; }
            }
     


    }
}
